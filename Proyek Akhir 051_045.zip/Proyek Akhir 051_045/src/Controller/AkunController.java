/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;


import View.AkunView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;

/**
 *
 * @author ASUS
 */
public class AkunController extends MouseAdapter implements ActionListener{
    AkunView view;
  
    
    
    public AkunController() {
        view = new AkunView();
        view.addActionListener(this);
        view.setVisible(true);
    }
    
    public void actionPerformed(ActionEvent d) {
        Object source = d.getSource();
        if (source.equals(view.getBtnGantiPin())) {
            view.dispose();
            new GantiPinController();
        }
        else if(source.equals(view.getBtnGantiPass())){
            view.dispose();
            new GantiPassController();
        }
        else if(source.equals(view.getBtnHapusAkun())){
            view.dispose();
            new HapusAkunController();
            
        }
        
    }
    
}
