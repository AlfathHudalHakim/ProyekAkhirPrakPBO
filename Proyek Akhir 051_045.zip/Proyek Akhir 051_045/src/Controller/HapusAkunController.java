/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.HapusAkunModel;
import View.HapusAkunView;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.ActionEvent;

/**
 *
 * @author ASUS
 */
public class HapusAkunController extends MouseAdapter implements ActionListener{
     HapusAkunView view;
    HapusAkunModel model;
    
    public HapusAkunController() {
        

        view = new HapusAkunView();
        model = new HapusAkunModel();
        view.addActionListener(this);
        view.setVisible(true);
    }
        
    
//    public void cek() {
//        
////        double saldo=0;
////        double uang1 = View.getSaldo();
////        double uang2 = tp.getUang();
////        String pin = tp.getPin();
////         saldo = uang1+uang2;
////                View.setSaldo(Double.toString(saldo));
////                return s = new Saldo(saldo);
//            }
//    
//    public void TopUp(){
//    
////        double uang1 = View.getSaldo();
////        double uang2 = tp.getUang();
////            uang1 = uang1 + uang2;
////            View.setSaldo(Double.toString(uang1));
////    double saldo =  View.getSaldo();
////    JOptionPane.showMessageDialog(view, "Berhasil TOP UP",
////                "Berhasil", JOptionPane.INFORMATION_MESSAGE);    
//        }
    
   
     public void actionPerformed(ActionEvent b) {
        Object source = b.getSource();
        if (source.equals(view.getBtnHapus())) {
           
            view.dispose();
           model.DeleteAkun();
            
        }
//        else if(source.equals(view.getbtnBack())){
//            view.dispose();
//                  try {      
//                String username = vew.getUsername();
//                String password = vew.getPassword();
//                if (!username.equals("") && !password.equals("")) {
//                    ResultSet rs = mdl.login(username,password);
//                
//                    if (rs.next()) {
//                        
//                        String nama = rs.getString(2);
//                        String saldo = rs.getString(6);
//                        new HomeController(nama,saldo);
//                    } else {
//                        JOptionPane.showMessageDialog(view, "User tidak ditemukan",
//                                "Error", JOptionPane.WARNING_MESSAGE);
//                        vew.resetForm();
//                    }
//                } 
//                  }catch (SQLException ex) {
//                    Logger.getLogger(TopUpController.class.getName()).log(Level.SEVERE, null, ex);
//                }
//                } else
//                    JOptionPane.showMessageDialog(view, "Username atau Password kosong!", 
//                            "Error", JOptionPane.WARNING_MESSAGE);
            
            
        }
}

