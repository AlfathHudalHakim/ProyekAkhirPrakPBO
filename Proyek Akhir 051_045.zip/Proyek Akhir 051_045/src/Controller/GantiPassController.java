/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.GantiPassModel;
import View.GantiPassView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;

/**
 *
 * @author ASUS
 */
public class GantiPassController extends MouseAdapter implements ActionListener{
    GantiPassView view;
    GantiPassModel model;
    
    public GantiPassController() {
        

        view = new GantiPassView();
        model = new GantiPassModel();
        view.addActionListener(this);
        view.setVisible(true);
    }
        
    
//    public void cek() {
//        
////        double saldo=0;
////        double uang1 = View.getSaldo();
////        double uang2 = tp.getUang();
////        String pin = tp.getPin();
////         saldo = uang1+uang2;
////                View.setSaldo(Double.toString(saldo));
////                return s = new Saldo(saldo);
//            }
//    
//    public void TopUp(){
//    
////        double uang1 = View.getSaldo();
////        double uang2 = tp.getUang();
////            uang1 = uang1 + uang2;
////            View.setSaldo(Double.toString(uang1));
////    double saldo =  View.getSaldo();
////    JOptionPane.showMessageDialog(view, "Berhasil TOP UP",
////                "Berhasil", JOptionPane.INFORMATION_MESSAGE);    
//        }
    
    @Override
     public void actionPerformed(ActionEvent b) {
        Object source = b.getSource();
        if (source.equals(view.getbtnGanti())) {
           
            view.dispose();
            model.UpdatePass();
        }
//        else if(source.equals(view.getbtnBack())){
//            view.dispose();
//                  try {      
//                String username = vew.getUsername();
//                String password = vew.getPassword();
//                if (!username.equals("") && !password.equals("")) {
//                    ResultSet rs = mdl.login(username,password);
//                
//                    if (rs.next()) {
//                        
//                        String nama = rs.getString(2);
//                        String saldo = rs.getString(6);
//                        new HomeController(nama,saldo);
//                    } else {
//                        JOptionPane.showMessageDialog(view, "User tidak ditemukan",
//                                "Error", JOptionPane.WARNING_MESSAGE);
//                        vew.resetForm();
//                    }
//                } 
//                  }catch (SQLException ex) {
//                    Logger.getLogger(TopUpController.class.getName()).log(Level.SEVERE, null, ex);
//                }
//                } else
//                    JOptionPane.showMessageDialog(view, "Username atau Password kosong!", 
//                            "Error", JOptionPane.WARNING_MESSAGE);
            
            
        }
}
