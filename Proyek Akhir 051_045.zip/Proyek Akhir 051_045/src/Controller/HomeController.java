/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;


import View.AkunView;
import View.HomeView;
import View.TopUpView;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class HomeController extends MouseAdapter implements ActionListener {
    HomeView view;
    TopUpView tp;
    private String nama;
    private String saldo;

    public HomeController(HomeView view) {
        this.view = view;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public void setSaldo(String saldo) {
        this.saldo = saldo;
    }

    public String getNama() {
        return nama;
    }

    public String getSaldo() {
        return saldo;
    }
   
    public void setting(){
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/YYY");
        Date date = new Date();
        String tgl = dateFormat.format(date);
        System.out.println(getSaldo());
        System.out.println(getNama());
        view = new HomeView();
        view.addActionListener(this);
        view.setVisible(true);
        view.setSaldo(this.getSaldo());
        view.setLabelHi(this.getNama());
        view.setLabelTanggal(tgl);  
        
    }
    public HomeController(){
    }
    
    
      
    
    
    
    
   
    @Override
    public void actionPerformed(ActionEvent c) {
        Object source = c.getSource();
        if (source.equals(view.getBtnLogout())) {
            view.dispose();
            new LoginController();
        }
        else if(source.equals(view.getBtnTop())){
            view.dispose();
            new TopUpController();
        }
        else if(source.equals(view.getBtnTrans())){
            view.dispose();
            new TransferController();
        }
        else if(source.equals(view.getBtnAkun())){
            view.dispose();
            new AkunController();
        }
        
    }
}