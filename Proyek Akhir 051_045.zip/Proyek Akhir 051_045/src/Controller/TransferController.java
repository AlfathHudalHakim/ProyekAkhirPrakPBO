/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.LoginModel;
import Model.TopUpModel;
import Model.TransferModel;
import View.HomeView;
import View.LoginView;
import View.TopUpView;
import View.TransferView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author ASUS
 */
public class TransferController extends MouseAdapter implements ActionListener{
    HomeView View;
    TransferView view;
    LoginView vew;
    LoginModel mdl;
    TransferModel model;
    TransferView tp;
    public TransferController() {
        

        view = new TransferView();
        model = new TransferModel();
        view.addActionListener(this);
        view.setVisible(true);
    }
        
    
//    public void cek() {
//        
////        double saldo=0;
////        double uang1 = View.getSaldo();
////        double uang2 = tp.getUang();
////        String pin = tp.getPin();
////         saldo = uang1+uang2;
////                View.setSaldo(Double.toString(saldo));
////                return s = new Saldo(saldo);
//            }
//    
//    public void TopUp(){
//    
////        double uang1 = View.getSaldo();
////        double uang2 = tp.getUang();
////            uang1 = uang1 + uang2;
////            View.setSaldo(Double.toString(uang1));
////    double saldo =  View.getSaldo();
////    JOptionPane.showMessageDialog(view, "Berhasil TOP UP",
////                "Berhasil", JOptionPane.INFORMATION_MESSAGE);    
//        }
    
    @Override
     public void actionPerformed(ActionEvent b) {
        Object source = b.getSource();
        if (source.equals(view.getBtnTransfer())) {
           
//            view.dispose();
            model.UpdateSaldo();
        }
        else if(source.equals(view.getbtnBack())){
            view.dispose();
                  try {      
                String username = vew.getUsername();
                String password = vew.getPassword();
                if (!username.equals("") && !password.equals("")) {
                    ResultSet rs = mdl.login(username,password);
                
                    if (rs.next()) {
                        
                        String nama = rs.getString(2);
                        String saldo = rs.getString(6);
                        new HomeController();
                    } else {
                        JOptionPane.showMessageDialog(view, "User tidak ditemukan",
                                "Error", JOptionPane.WARNING_MESSAGE);
                        vew.resetForm();
                    }
                } 
                  }catch (SQLException ex) {
                    Logger.getLogger(TopUpController.class.getName()).log(Level.SEVERE, null, ex);
                }
                } else
                    JOptionPane.showMessageDialog(view, "Username atau Password kosong!", 
                            "Error", JOptionPane.WARNING_MESSAGE);
            
            
        }
}
