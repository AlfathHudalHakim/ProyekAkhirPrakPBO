/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import View.GantiPinView;
import View.HomeView;


import static View.GantiPinView.PinBaru;
import static View.GantiPinView.PinLama;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author ASUS
 */
public class GantiPinModel {
    private Connection con;
    Statement st;
    GantiPinView view;
    HomeView View;
    
    public GantiPinModel() {
        
        ;
}
    public void UpdatePin(){
       
       int pin = Integer.parseInt(PinLama.getText());
       int pin1 = Integer.parseInt(PinBaru.getText());
       
 
        String sql = "Update regis Set pin='"+  pin1 + "'where pin='"+ pin  +"'";
        
        try {
        Class.forName("com.mysql.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank","root","");
        st = con.createStatement();
        st.executeUpdate(sql);
        JOptionPane.showMessageDialog(null," Ganti Pin berhasil, Silahkan Memulai Ulang Program ");
        }
    catch(Exception ex){
    JOptionPane.showMessageDialog(null,"Gagal terkoneksi Karena " + ex);
}
   }

}
