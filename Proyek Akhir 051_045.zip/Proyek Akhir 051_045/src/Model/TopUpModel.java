/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import Controller.TopUpController;
import View.HomeView;
import View.TopUpView;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import static View.HomeView.tfsaldo;
import static View.TopUpView.tfuang;
import static View.TopUpView.tfpin;
import java.sql.DriverManager;

/**
 *
 * @author ASUS
 */
public class TopUpModel {
    private Connection con;
    Statement st;
    TopUpView view;
    HomeView View;
    
    public TopUpModel() {
        
        ;
}
    public void UpdateSaldo(){
       double uang1 =  Double.parseDouble(tfsaldo.getText());
       double uang2 = Double.parseDouble(tfuang.getText());
       int pin = Integer.parseInt(tfpin.getText());
       
       uang1 = uang1 + uang2;
        String sql = "Update regis Set saldo='"+ uang1  + "'where pin='"+ pin  +"'";
        tfsaldo.setText(""+ uang1 + "");
        try {
        Class.forName("com.mysql.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank","root","");
        st = con.createStatement();
        st.executeUpdate(sql);
        JOptionPane.showMessageDialog(null," TopUp Berhasil ");    
        }
    catch(Exception ex){
    JOptionPane.showMessageDialog(null,"Gagal terkoneksi Karena " + ex);
}
   }

    
}
