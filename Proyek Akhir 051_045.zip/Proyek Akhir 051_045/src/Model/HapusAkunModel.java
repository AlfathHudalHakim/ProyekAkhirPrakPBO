/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import View.HapusAkunView;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.swing.JOptionPane;
import static View.HapusAkunView.HapusAkun;

/**
 *
 * @author ASUS
 */
public class HapusAkunModel {
    private Connection con;
    Statement st;
    HapusAkunView view;
    
    public  HapusAkunModel() {
        
        
}
    public void DeleteAkun(){
       
       int pin = Integer.parseInt(HapusAkun.getText());
     
       
 
        String sql = "Delete FROM regis WHERE pin='"+  pin + "'";
        
        try {
        Class.forName("com.mysql.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank","root","");
        st = con.createStatement();
        st.executeUpdate(sql);
        JOptionPane.showMessageDialog(null," Hapus Akun berhasil, Silahkan Memulai Ulang Program ");
        }
    catch(Exception ex){
    JOptionPane.showMessageDialog(null,"Gagal terkoneksi Karena " + ex);
}
   }
}
