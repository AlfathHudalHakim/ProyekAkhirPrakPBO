/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import View.HomeView;
import static View.HomeView.tfsaldo;
import View.TopUpView;
import static View.TransferView.tfpin1;
import static View.TransferView.tfuang1;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author ASUS
 */
public class TransferModel {
   private Connection con;
    Statement st;
    TopUpView view;
    HomeView View;
    
    public TransferModel() {
        
        ;
}
    public void UpdateSaldo(){
       double uang1 =  Double.parseDouble(tfsaldo.getText());
       double uang2 = Double.parseDouble(tfuang1.getText());
       int pin = Integer.parseInt(tfpin1.getText());
       
       uang1 = uang1 - uang2;
        String sql = "Update regis Set saldo='"+ uang1  + "'where pin='"+ pin  +"'";
        tfsaldo.setText(""+ uang1 + "");
        try {
        Class.forName("com.mysql.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank","root","");
        st = con.createStatement();
        st.executeUpdate(sql);
        JOptionPane.showMessageDialog(null," Transfer Berhasil ");
        }
    catch(Exception ex){
    JOptionPane.showMessageDialog(null,"Gagal terkoneksi Karena " + ex);
}
   } 
}
