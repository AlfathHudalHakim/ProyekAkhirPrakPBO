/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import static View.GantiPassView.PassBaru;
import static View.GantiPassView.PassLama;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author ASUS
 */
public class GantiPassModel {
    private Connection con;
    Statement st;
    
    public GantiPassModel() {
        
        ;
}
    public void UpdatePass(){
       
       int pass = Integer.parseInt(PassLama.getText());
       int pass1 = Integer.parseInt(PassBaru.getText());
       
 
        String sql = "Update regis Set password='"+  pass1 + "'where pas='"+ pass  +"'";
        
        try {
        Class.forName("com.mysql.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank","root","");
        st = con.createStatement();
        st.executeUpdate(sql);
        JOptionPane.showMessageDialog(null," Ganti Password Berhasil, Silahkan Memulai Ulang Program ");
        }
    catch(Exception ex){
    JOptionPane.showMessageDialog(null,"Gagal terkoneksi Karena " + ex);
}
   }
}
